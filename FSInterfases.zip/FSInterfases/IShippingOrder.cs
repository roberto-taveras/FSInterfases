﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace FSInterfaces
{

    interface IShippingOrder
    {
       
        ConsigneePaymentType ConsigneePaymentType { get; set; }
        DateTime? CreatedDate { get; set; }
        DateTime? DeliveryDate { get; set; }
        PackageType? IdPackageType { get; set; }

        decimal ImportDuties { get; set; }
        string InternalTrackingNumber { get; set; }
        string InvoiceNumber { get; set; }
        bool IsConsigneeCollectPayment { get; set; }
        string Note { get; set; }
        int PackageQty { get; set; }
        List<Product> Products { get; set; }
        decimal TransportFee { get; set; }
        string UserDefine1 { get; set; }
        string UserDefine2 { get; set; }
        string UserDefine3 { get; set; }
        string UserDefine4 { get; set; }
        string UserDefine5 { get; set; }
    }
}
