﻿using System;
using System.Collections.Generic;
namespace FSInterfaces
{
    public interface IFSShippingResult
    {
        List<ShippingResult> ShippingResults { get; set; }
        string ShippingOrder { get; set; }
    }
}
