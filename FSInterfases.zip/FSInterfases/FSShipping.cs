﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;

namespace FSInterfaces
{
    /// <summary>
    /// 
    /// </summary>
    public enum ServiceType { None, Ltl, Fcl, Ftl, HD }
    public class FSShipping : IFSShipping
    {
        [JsonProperty]
        [Range((int)ServiceType.Ltl, (int)ServiceType.HD)]
        public ServiceType ServiceType { get; set; }
        public FSShipping()
        {
            Consignees = new List<Consignee>();
        }


        [StringLength(50), Required]
        public string ShippingOrder { get; set; }


        [StringLength(30), Required]
        public string DocumentNumber { get; set; }


        public DateTime? ShippingDate { get; set; }

     
        public List<Consignee> Consignees { get; set; }

        [StringLength(150)]
        public string UserDefine1 { get; set; }


        [StringLength(150)]
        public string UserDefine2 { get; set; }


        [StringLength(150)]
        public string UserDefine3 { get; set; }


        [StringLength(150)]
        public string UserDefine4 { get; set; }


        [StringLength(150)]
        public string UserDefine5 { get; set; }

        public FSShippingType ShippingType { get; set; }



    }
}
