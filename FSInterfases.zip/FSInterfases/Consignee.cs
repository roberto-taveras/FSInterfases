﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;

namespace FSInterfaces
{
    

    [ConsigneeDocumentNumberAttribute()]
    public class Consignee : IConsignee
    {

        public Consignee()
        {
            ShippingOrders = new List<ShippingOrder>();
        }


        public static string GetDocumentType(Consignee consignee)
        {
            return consignee.ConsigneeDocumentType;
        }


             
        [JsonProperty]
        [StringLength(150), Required]
        public string ConsigneeName { get; set; }

        [JsonProperty]
        [StringLength(150)]
        public string ConsigneeContactName { get; set; }


        [JsonProperty]
        [StringLength(10)]
        public string ConsigneeDocumentType { get; set; }

        
        [JsonProperty]
        [StringLength(20)]
        public string ConsigneeDocumentNumber { get; set; }

        [JsonProperty]
        [StringLength(250), Required]
        public string ConsigneeAddress { get; set; }

        [JsonProperty]
        [StringLength(100), Required]
        public string ConsigneeSector { get; set; }

        [JsonProperty]
        [StringLength(100), Required]
        public string ConsigneeTown { get; set; }

        [JsonProperty]
        [StringLength(100)]
        public string ConsigneeZone { get; set; }

        [JsonProperty]
        [StringLength(15), Required]
        public string ConsigneeTelephone1 { get; set; }

        [JsonProperty]
        [StringLength(15)]
        public string ConsigneeTelephone2 { get; set; }

        [JsonProperty]
        [StringLength(15)]
        public string ConsigneeMobile { get; set; }

        [JsonProperty]
        [StringLength(50)]
        public string ConsigneeEmail { get; set; }

        [JsonProperty]
        [StringLength(50)]
        public string ConsigneeLatitude { get; set; }

        [JsonProperty]
        [StringLength(50)]
        public string ConsigneeLongitude { get; set; }

        [JsonProperty]
        public bool ConsigneeAppointment { get; set; }

        [JsonProperty]
        [StringLength(12)]
        public string ConsigneeAppointmentWindowStart { get; set; }

        [JsonProperty]
        [StringLength(12)]
        public string ConsigneeAppointmentWindowEnd { get; set; }


        [JsonProperty]
        [StringLength(150)]
        public string ShipperName { get; set; }


        [JsonProperty]
        public bool CollectionAppointment { get; set; }

        [JsonProperty]
        [StringLength(12)]
        public string CollectionAppointmentWindowStart { get; set; }

        [JsonProperty]
        [StringLength(12)]
        public string CollectionAppointmentWindowEnd { get; set; }


        [JsonProperty]
        [StringLength(250)]
        public string CollectionAddress { get; set; }

        [JsonProperty]
        [StringLength(100)]
        public string CollectionSector { get; set; }

        [JsonProperty]
        [StringLength(100)]
        public string CollectionTown { get; set; }


        [JsonProperty]
        [StringLength(100)]
        public string CollectionZone { get; set; }

        [JsonProperty]
        [StringLength(50)]
        public string CollectionLatitude { get; set; }

        [JsonProperty]
        [StringLength(50)]
        public string CollectionLongitude { get; set; }

        [JsonProperty]
        [StringLength(15)]
        public string ShipperTelephone { get; set; }


        public List<ShippingOrder> ShippingOrders { get; set; }

        public string ShipperClient { get; set; }


    }
}
