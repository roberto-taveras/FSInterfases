﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FSInterfaces
{
  public class InventorySynapse
  {
    //SELECT CUSTID,CUSTNAME,FACILITY,ITEM,ITEMDESCR,LOTNUMBER,NVL(SERIALNUMBER,' ') AS SERIALNUMBER,UOM,QTY,WEIGHT_KGS,LITERS,INVCLASS,INVSTATUS, LOT, PRECIO from CUSTITEMTOTSUM_NOVA_VIEW 
    public string CustId { get; set; }
    public string CustName { get; set; }
    public string Facility { get; set; }
    public string Item { get; set; }
    public string Description { get; set; }
    public string LotNumber { get; set; }
    public string SerialNumber { get; set; }
    public string UOM { get; set; }
    public int Qty { get; set; }
    public int Cases { get; set; }
    public decimal WeghtKgs { get; set; }
    public decimal Liters { get; set; }
    public string InvClass { get; set; }
    public string InvStatus { get; set; }
    public string Color { get; set; }
    public decimal Price { get; set; }
    public string Lot { get; set; }
  }
}
