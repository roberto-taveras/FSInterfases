﻿using System;
using System.Collections.Generic;
namespace FSInterfaces
{
    interface IFSShipping
    {
        ServiceType ServiceType { get; set; }
        List<Consignee> Consignees { get; set; }
        DateTime? ShippingDate { get; set; }
        string DocumentNumber { get; set; }
        string ShippingOrder { get; set; }
        string UserDefine1 { get; set; }
        string UserDefine2 { get; set; }
        string UserDefine3 { get; set; }
        string UserDefine4 { get; set; }
        string UserDefine5 { get; set; }
        FSShippingType ShippingType { get; set; }
    }
}
