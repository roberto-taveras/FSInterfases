﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;

namespace FSInterfaces
{

    public class FSLogin : IFSLogin
    {
        
        public string UserCode { get; set; }

        public string CompanyName { get; set; }

        public string LastName { get; set; }

        public DateTimeOffset AbsoluteExpiration { get; set; }

        public int CustomerId { get; set; }

    }
}
