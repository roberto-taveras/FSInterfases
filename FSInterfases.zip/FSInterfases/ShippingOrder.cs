﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;

namespace FSInterfaces
{

    //1             = Seco-N
    //2             = Frio
    //3             = Mixto
    //4             = Documentos
    //6             = Otras Cajas
    //9             = Seco-G
    //10            = Paleta
    public enum PackageType { Documentos = 4, Paleta = 10, Recogida = 11,CajasNormales = 12,CajasMedianas = 13,CajasGrandes = 14 }
    public enum ConsigneePaymentType { None, Credit, CreditCard, Cash }
    public class ShippingOrder : IShippingOrder 
    {
        public ShippingOrder()
        {
            Products = new List<Product>();
        }

       
        public DateTime? CreatedDate { get; set; }

        [StringLength(50), Required]
        public string InvoiceNumber { get; set; }
       
        [StringLength(50)]
        public string PurchaseOrder { get; set; }
     
        [StringLength(150)]
        public string InternalTrackingNumber { get; set; }
        public List<Product> Products  { get; set; }
        public decimal ImportDuties { get; set; }
        public decimal TransportFee { get; set; }
        public bool IsConsigneeCollectPayment { get; set; }
        [Range((int)ConsigneePaymentType.Credit, (int)ConsigneePaymentType.Cash)]
        public ConsigneePaymentType ConsigneePaymentType { get; set; }
      
        [Required]
        public int PackageQty { get; set; }
        public PackageType? IdPackageType { get; set; }
        public DateTime? DeliveryDate { get; set; }
       
        [StringLength(512)]
        public string Note { get; set; }
        [StringLength(150)]
        public string UserDefine1 { get; set; }

        [StringLength(150)]
        public string UserDefine2 { get; set; }
      
        [StringLength(150)]
        public string UserDefine3 { get; set; }
       
        [StringLength(150)]
        public string UserDefine4 { get; set; }
      
        [StringLength(150)]
        public string UserDefine5 { get; set; }


    }
}
