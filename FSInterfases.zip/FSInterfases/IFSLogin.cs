﻿using System;
namespace FSInterfaces
{
    public  interface IFSLogin
    {
        DateTimeOffset AbsoluteExpiration { get; set; }
        string CompanyName { get; set; }
        string LastName { get; set; }
        string UserCode { get; set; }
    }
}
