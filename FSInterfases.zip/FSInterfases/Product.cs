﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;

namespace FSInterfaces
{
    public class Product : IProduct
    {
        public PackageType? IdPackageType { get; set; }
        [StringLength(50)]
		[Required]
        public string ProductCode { get; set; }


        [StringLength(100)]
        [Required]
		public string ProductDescription { get; set; }


        public decimal Qty { get; set; }

        public decimal ProductPrice { get; set; }

    }
}
