﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FSInterfaces
{
    public enum FSVehicleStatus { OnBoard, Unloaded, NotFound }
    public class FSUnloadVehicle
    {

        public int Id { get; set; }
        [Required]
        public string DischargeDate { get; set; }
        public bool? Discharge { get; set; }
        public string ModifiedMobilUser { get; set; }
        public string ModifiedMobilDate { get; set; }
        public string DischargeNote { get; set; }
        public int IsSync { get; set; }
        public short KeysQty { get; set; }
        public bool Transit { get; set; }
        public bool NoRunner { get; set; }
        public bool Damage { get; set; }
        [Required]
        public FSVehicleStatus VehicleStatus { get; set; }
    }
}
