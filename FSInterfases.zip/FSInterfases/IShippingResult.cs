﻿using System;
namespace FSInterfaces
{
    public interface IShippingResult
    {
        string InternalTrackingNumber { get; set; }
        string ConsigneeDocumentNumber { get; set; }
        string InvoiceNumber { get; set; }

    }
}
