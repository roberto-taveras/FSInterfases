﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FSInterfaces
{
    public class ProductSynapse
    {
        public string CustId { get; set; }
        public string CustName { get; set; }
        public string Item { get; set; }
        public string Description { get; set; }
        public string BaseUoM { get; set; }
        //SELECT CUSTID,CUSTNAME,ITEM,DESCR,BASEUOM FROM CUSTITEMVIEW
    }
}
