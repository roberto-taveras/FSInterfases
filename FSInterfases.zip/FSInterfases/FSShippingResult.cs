﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;

namespace FSInterfaces
{
    public class FSShippingResult : IFSShippingResult
    {
        public FSShippingResult()
        {
            ShippingResults = new List<ShippingResult>();
        }


        [StringLength(50), Required]
        public string ShippingOrder { get; set; }

        public List<ShippingResult> ShippingResults { get; set; }
    }
}
