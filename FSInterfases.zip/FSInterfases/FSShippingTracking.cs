﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;

namespace FSInterfaces
{
    public class TrackingHistory 
    {

        public int IdStatus { get; set; }


        public DateTime DateTransaction { get; set; }


        public string StatusDescription { get; set; }


        public string Note { get; set; }
 
    }

    public class FSShippingTracking  
    {
        public FSShippingTracking()
        {
            Trackings = new List<ShippingTracking>();
        }
       public List<ShippingTracking> Trackings { get; set; }
    }
}
