﻿using System;
namespace FSInterfaces.Helpers
{
    interface IValidationResult
    {
        string ErrorMessage { get; set; }
        int Index { get; set; }
        System.Collections.Generic.IEnumerable<string> MemberNames { get; }
    }
}
