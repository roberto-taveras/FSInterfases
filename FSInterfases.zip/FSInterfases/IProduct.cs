﻿using System;
namespace FSInterfaces
{
    interface IProduct
    {
        string ProductCode { get; set; }
        string ProductDescription { get; set; }
        decimal ProductPrice { get; set; }
        decimal Qty { get; set; }
    }
}
