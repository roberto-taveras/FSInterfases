﻿using System;
using System.Collections.Generic;
using System.Linq;
using FSInterfaces;
using System.IO;


namespace TestFSService
{
    class Program
    {
        static FSService.FSServiceSoapClient testWS = new FSService.FSServiceSoapClient();
        static void Main(string[] args)
        {
            File.WriteAllText("FSShipping.json", createFSShipping());

        }

            private static string getTracking()
            {

                FSInternalTrackingNumber trackingNumber = new FSInternalTrackingNumber();
                trackingNumber.TrackingNumber = "053002686451006676";
                string sent = string.Empty;
                //FSTrackingNumberList tl = new FSTrackingNumberList();
                //tl.TrackingNumbers.Add(trackingNumber);
                sent = Newtonsoft.Json.JsonConvert.SerializeObject(trackingNumber);
                File.WriteAllText("FSInternalTrackingNumber.json", sent);
                return sent;
                //File.WriteAllText("FSShippingTrackingResult.json", testWS.GetShippingTrackingList(key, sent));

            }

            private static string createFSShipping()
            {
                FSShipping fsShipping = new FSShipping();
                fsShipping.ShippingDate = DateTime.Now;
                fsShipping.ShippingOrder = "0001BU01";
                fsShipping.ServiceType = ServiceType.Ltl;
                fsShipping.DocumentNumber = "101010215";
                fsShipping.ShippingType = FSShippingType.Delivery;
                Consignee consignee = new Consignee();

                consignee.ConsigneeName = "Jose Roberto Taveras";
                consignee.ConsigneeDocumentType = "SA13-CED"; // Si es una persona fisica
                //consignee.ConsigneeDocumentType = "SA13-RNC"; //Si es un RNC

                consignee.ConsigneeDocumentNumber = "05300268645";
                consignee.ConsigneeEmail = "jrtaveras@schad.do";
                consignee.ConsigneeAddress = "Avenida Isabel Aguiar, Edificio Rosa Apto.B24";
                consignee.ConsigneeTown = "Santo Domingo Oeste";
                consignee.ConsigneeSector = "Herrera";
                consignee.ConsigneeZone = "Sur";
                consignee.ConsigneeTelephone1 = "8296620002";
                consignee.ShipperName = "Juan Salcedo";
                consignee.CollectionAddress = "calle 10 no 59 enz isabelita, STO DGO Este";
                consignee.ShipperTelephone = "8498896410";

                ShippingOrder shippingOrder = new ShippingOrder();
                shippingOrder.CreatedDate = DateTime.Now;
                shippingOrder.InvoiceNumber = "ORD2514781";
                shippingOrder.InternalTrackingNumber = null;
                shippingOrder.PackageQty = 10;
                shippingOrder.ConsigneePaymentType = ConsigneePaymentType.Credit;
                shippingOrder.DeliveryDate = DateTime.Now.AddDays(1);
                shippingOrder.Products.Add(new Product() { ProductCode = "0001", ProductDescription = "Producto001", Qty = 5, ProductPrice = 100.00M });
                shippingOrder.Products.Add(new Product() { ProductCode = "0002", ProductDescription = "Producto002", Qty = 3, ProductPrice = 200.00M });
                shippingOrder.Products.Add(new Product() { ProductCode = "0003", ProductDescription = "Producto003", Qty = 2, ProductPrice = 300.00M });
                shippingOrder.IdPackageType = null;
                shippingOrder.DeliveryDate = DateTime.Now.AddDays(1);
                consignee.ShippingOrders.Add(shippingOrder);



                shippingOrder = new ShippingOrder();
                shippingOrder.CreatedDate = DateTime.Now;
                shippingOrder.InvoiceNumber = "ORD2514791";
                shippingOrder.InternalTrackingNumber = null;
                shippingOrder.PackageQty = 5;
                shippingOrder.ConsigneePaymentType = ConsigneePaymentType.Credit;
                shippingOrder.DeliveryDate = DateTime.Now.AddDays(1);
                shippingOrder.Products.Add(new Product() { ProductCode = "0004", ProductDescription = "Producto001", Qty = 3, ProductPrice = 400.00M });
                shippingOrder.Products.Add(new Product() { ProductCode = "0005", ProductDescription = "Producto002", Qty = 1, ProductPrice = 500.00M });
                shippingOrder.Products.Add(new Product() { ProductCode = "0006", ProductDescription = "Producto003", Qty = 1, ProductPrice = 600.00M });
                shippingOrder.IdPackageType = null;
                shippingOrder.DeliveryDate = DateTime.Now.AddDays(1);
                consignee.ShippingOrders.Add(shippingOrder);

                fsShipping.Consignees.Add(consignee);

                consignee = new Consignee();

                consignee.ConsigneeName = "Ramon Peralta";
                consignee.ConsigneeDocumentType = "SA13-CED";
                consignee.ConsigneeDocumentNumber = "00117754796";
                consignee.ConsigneeEmail = "jrtaveras@schad.do";
                consignee.ConsigneeAddress = "Calle la torre No 81";
                consignee.ConsigneeTown = "D.N.";
                consignee.ConsigneeSector = "Herrera";
                consignee.ConsigneeZone = "SUR";
                consignee.ConsigneeTelephone1 = "8299045948";
                consignee.ShipperName = "Juan Salcedo";
                consignee.CollectionAddress = "calle 10 no 59 enz isabelita, STO DGO Este";
                consignee.ShipperTelephone = "8498896410";

                shippingOrder = new ShippingOrder();
                shippingOrder.CreatedDate = DateTime.Now;
                shippingOrder.InvoiceNumber = "ORD2514401";
                shippingOrder.InternalTrackingNumber = null;
                shippingOrder.ConsigneePaymentType = ConsigneePaymentType.Credit;
                shippingOrder.PackageQty = 10;
                shippingOrder.DeliveryDate = DateTime.Now.AddDays(1);
                shippingOrder.Products.Add(new Product() { ProductCode = "0001", ProductDescription = "Producto001", Qty = 5, ProductPrice = 100.00M });
                shippingOrder.Products.Add(new Product() { ProductCode = "0002", ProductDescription = "Producto002", Qty = 3, ProductPrice = 200.00M });
                shippingOrder.Products.Add(new Product() { ProductCode = "0003", ProductDescription = "Producto003", Qty = 2, ProductPrice = 300.00M });
                shippingOrder.DeliveryDate = DateTime.Now.AddDays(1);
                shippingOrder.IdPackageType = null;

                consignee.ShippingOrders.Add(shippingOrder);

                fsShipping.Consignees.Add(consignee);




                string result = string.Empty;
                result = Newtonsoft.Json.JsonConvert.SerializeObject(fsShipping);
                return result;
            }


        }
}

