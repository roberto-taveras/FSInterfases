﻿using System;
namespace FSInterfaces
{
    interface IConsignee
    {

        string CollectionAddress { get; set; }
        bool CollectionAppointment { get; set; }
        string CollectionAppointmentWindowEnd { get; set; }
        string CollectionAppointmentWindowStart { get; set; }
        string CollectionLatitude { get; set; }
        string CollectionLongitude { get; set; }
        string CollectionSector { get; set; }
        string CollectionTown { get; set; }
        string CollectionZone { get; set; }
        string ConsigneeAddress { get; set; }
        bool ConsigneeAppointment { get; set; }
        string ConsigneeAppointmentWindowEnd { get; set; }
        string ConsigneeAppointmentWindowStart { get; set; }
        string ConsigneeContactName { get; set; }
        string ConsigneeDocumentType { get; set; }
        string ConsigneeDocumentNumber { get; set; }
        string ConsigneeEmail { get; set; }
        string ConsigneeLatitude { get; set; }
        string ConsigneeLongitude { get; set; }
        string ConsigneeMobile { get; set; }
        string ConsigneeName { get; set; }
        string ConsigneeSector { get; set; }
        string ConsigneeTelephone1 { get; set; }
        string ConsigneeTelephone2 { get; set; }
        string ConsigneeTown { get; set; }
        string ConsigneeZone { get; set; }
        string ShipperName { get; set; }
        string ShipperTelephone { get; set; }
        string ShipperClient { get; set; }
        System.Collections.Generic.List<ShippingOrder> ShippingOrders { get; set; }
    }
}
