﻿using FSInterfaces.Helpers;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FSInterfaces.CustomValidations
{
    public class TrackingNumberAttribute: ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            var result = true;
            if (value.ToString().Length < 2)
            {
                result = false;
                this.ErrorMessage = "El campo debe tener al menos dos caracteres!";
            }
            else
            {
              
                var invoice = value.ToString();
                invoice = invoice.Substring(0, invoice.Length - 1);
                var trackingNumber = HelperGenerateTracking.Generate(invoice);
                if (!trackingNumber.Equals(value.ToString()))
                {
                    result = false;
                    this.ErrorMessage = "El digito verificador esta mal en esta factura!";
                }
            }
            return result;
        }
       
    }
}
