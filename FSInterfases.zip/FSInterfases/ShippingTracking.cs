﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FSInterfaces
{
    public class ShippingTracking : IShippingTracking
    {
        public ShippingTracking()
        {
            TrackingHistory = new List<TrackingHistory>();
        }


        public string InternalTrackingNumber { get; set; }


        public string ConsigneeDocumentNumber { get; set; }


        public string ConsigneeName { get; set; }


        public int DeliveryOrderId { get; set; }

        public string InvoiceNumber { get; set; }

        public DateTime DateTransaction { get; set; }


        public int PackageQty { get; set; }


        public string Location { get; set; }



        public int IdStatus { get; set; }


        public string StatusDescription { get; set; }


        public int? IdShipper { get; set; }


        public string Shipper { get; set; }


        public string Note { get; set; }


        public List<TrackingHistory> TrackingHistory { get; set; }

    }
}
