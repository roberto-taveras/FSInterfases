﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;

namespace FSInterfaces
{
    public class ConsigneeDocumentNumberAttribute : ValidationAttribute
    {
        private const string documentTypeCedula = "SA13-CED";
        private const string documentTypeRNC = "SA13-RNC";

        public string DocumentType { get; set; }
        public override bool IsValid(object value)
        {
           Consignee consignee = value as Consignee ;
           bool result = consignee != null;

            if(result)
            {
               switch (consignee.ConsigneeDocumentType)
	           {
		            case documentTypeCedula:
                       result = ValidarCedula(consignee.ConsigneeDocumentNumber);
                        if (!result)
                            ErrorMessage = string.Format("The document number {0} es invalid for the documenttype {1}", consignee.ConsigneeDocumentNumber, consignee.ConsigneeDocumentType);
                       break;

                   case documentTypeRNC:
                       result = ValidarRNC(consignee.ConsigneeDocumentNumber);
                        if (!result)
                            ErrorMessage = string.Format("The document number {0} es invalid for the documenttype {1}", consignee.ConsigneeDocumentNumber, consignee.ConsigneeDocumentType);
                        break;

	           }
            }
           
           return result;
        }

        public  bool ValidarCedula(string numeroCedula)
        {
            Regex oRegex = new Regex("[^0-9]");
            numeroCedula = oRegex.Replace(numeroCedula, "");

            if (numeroCedula.Length != 11)
                return false;

            string cedula = numeroCedula.Substring(0, numeroCedula.Length - 1);

            int verificador = Convert.ToInt32(numeroCedula[10].ToString());
            int suma = 0;

            for (int i = 0; i < 10; i++)
            {
                int result = Convert.ToInt32(cedula[i].ToString()) * ((i % 2) + 1);
                if (result > 9)
                {
                    string auxResult = result.ToString();
                    result = Convert.ToInt32(auxResult[0].ToString()) + Convert.ToInt32(auxResult[1].ToString());
                }

                suma += result;
            }

            return ((10 - (suma % 10)) % 10) == verificador;
        }

        public bool ValidarRNC(string numeroRNC)
        {
            char[] peso = { '7', '9', '8', '6', '5', '4', '3', '2' };
            int suma = 0;
            int division = 0;
            int resto = 0;
            int digito = 0;
            Regex oRegex = new Regex("[^0-9]");

            numeroRNC = oRegex.Replace(numeroRNC, "");

            if (numeroRNC.Length != 9)
                return false;

            for (int i = 0; i < 8; i++)
            {
                suma += (int)(char.GetNumericValue(numeroRNC[i]) * char.GetNumericValue(peso[i]));
            }

            division = suma / 11;
            resto = suma - (division * 11);

            if (resto == 0)
                digito = 2;
            else if (resto == 1)
                digito = 1;
            else
                digito = 11 - resto;

            return (digito == char.GetNumericValue(numeroRNC[8]));
        }
    
    
    }
}
