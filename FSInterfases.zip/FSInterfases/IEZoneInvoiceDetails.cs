﻿using System.Collections.Generic;

namespace FSInterfaces
{
    public interface IEZoneInvoiceDetails
    {
        string AwbNumber { get; set; }
        List<Charges> Charges { get; set; }
        string InvoiceNumber { get; set; }
        decimal TotalAmount { get; set; }
    }
}