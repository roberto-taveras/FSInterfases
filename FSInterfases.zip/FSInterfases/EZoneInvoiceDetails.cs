﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FSInterfaces
{
    public class Charges
    {
        [StringLength(80), Required]
        public string ChargeName { get; set; }

        [Required]
        public decimal ChargeAmount { get; set; }
    }
    public class EZoneInvoiceDetails : IEZoneInvoiceDetails
    {
        public EZoneInvoiceDetails()
        {
            Charges = new List<Charges>();
        }

        [StringLength(25), Required]
        public string AwbNumber { get; set; }

        [Required]
        public decimal TotalAmount { get; set; }

        [StringLength(25), Required]
        public string InvoiceNumber { get; set; }

        public DateTime InvoiceDate { get; set; }

        [Range(1,999999999)]
        public List<Charges> Charges { get; set; }
    }
}
