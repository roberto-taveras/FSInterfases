﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FSInterfaces
{
    public enum FSShippingType
    {
      Delivery = 1 , Pickup  
    }
}
