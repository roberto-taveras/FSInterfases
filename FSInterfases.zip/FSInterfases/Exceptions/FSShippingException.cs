﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FSInterfaces.Exeptions
{
    public class FSShippingException : Exception
    {
        public FSShippingException():base()
        {

        }

        public FSShippingException(string message):base(message)
        {
           
        }

        public FSShippingException(string message, Exception inner) : base(message, inner)
        {
        }

    }

}
