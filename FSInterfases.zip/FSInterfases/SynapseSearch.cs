﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FSInterfaces
{
    public class SynapseSearchProduct
    {
        public string CustomerId { get; set; }
        public string Sender { get; set; }
    }



    public class SynapseSearchInventory
    {
        public string CustomerId { get; set; }
        public string Facility { get; set; }
        public string Sender { get; set; }
        public string InvClass { get; set; }
        public string InvStatus { get; set; }
        public string Bl { get; set; }
    }
}
