﻿using System;
using System.Collections.Generic;

namespace FSInterfaces
{
    public interface IShippingTracking
    {
        string ConsigneeDocumentNumber { get; set; }
        string ConsigneeName { get; set; }
        DateTime DateTransaction { get; set; }
        int DeliveryOrderId { get; set; }
        int? IdShipper { get; set; }
        int IdStatus { get; set; }
        string InternalTrackingNumber { get; set; }
        string InvoiceNumber { get; set; }
        string Location { get; set; }
        string Note { get; set; }
        int PackageQty { get; set; }
        string Shipper { get; set; }
        string StatusDescription { get; set; }
        List<TrackingHistory> TrackingHistory { get; set; }
    }
}