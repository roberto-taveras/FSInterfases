﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FSInterfaces
{
    public class FSUnloadVoyage
    {

        public int Id { get; set; }
        public bool Unload { get; set; }
        public string UnloadDate { get; set; }
    }
}
