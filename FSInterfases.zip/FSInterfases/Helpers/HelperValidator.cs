﻿using System.ComponentModel.DataAnnotations;
using System;
using System.Linq;
using System.Collections.Generic;
using Newtonsoft.Json;
using System.Text;
using System.Collections;
namespace FSInterfaces.Helpers
{

    public class ValidationResult : FSInterfaces.Helpers.IValidationResult
    {
        
        private string errorMessage = string.Empty;
        private IEnumerable<string> memberNames = new List<string>();
        public ValidationResult(string errorMessage) { }
        public void SetErrors(string errorMessage, IEnumerable<string> memberNames)
        {
            this.errorMessage = errorMessage;
            this.memberNames = memberNames;
        }

        public ValidationResult()
        {
        }


        public string EntityName { get;set; }


        public int Index { get; set; }


        public string ErrorMessage { get { return errorMessage; } set { errorMessage = value; } }


        public IEnumerable<string> MemberNames { get { return memberNames; } }
    }

    
    public class HelperValidator
    {
      
        public static void Validate(object entity, List<ValidationResult> validationResultList)
        {

            int index = 0;
            if (validationResultList.Count() > 0)
            {
                index += validationResultList.Select(x=>x.Index).Max() + 1; 
            }

            if (entity.GetType().GetInterfaces().Where(a => a.Name.Contains("IList")).FirstOrDefault() == null)
            {
                validateRequired(entity, validationResultList, index);


                validateStringLength(entity, validationResultList, index);


                validateRange(entity, validationResultList, index);


                validateConsigneeDocumentNumber(entity, validationResultList, index);
            }

           
            foreach (var prop in entity.GetType().GetProperties())
            {
                var foundList = entity.GetType().GetInterfaces().Where(a => a.Name.Contains("IList")).FirstOrDefault();
                if (entity == null)
                    break;

                object currentValue = prop.GetValue(entity, null);
                if (currentValue != null) 
                {

                    if (currentValue.GetType().ToString().Contains("System.Int32") && foundList != null) 
                    {
                        foreach (var item in entity as IList)
                        {
                            Validate(item, validationResultList);

                        }
                        break;
                    }
                    else if (currentValue.GetType().GetInterfaces().Where(a => a.Name.Contains("IList")).FirstOrDefault() != null) 
                    {
                        var found = currentValue.GetType().GetInterfaces().Where(a => a.Name.Contains("IList")).FirstOrDefault();
                        if (found != null && currentValue != null)
                        {

                            foreach (var item in currentValue as IList)
                            {
                                Validate(item, validationResultList);

                            }

                        }
                    }
                }
    
            }
        }


        private static bool validateConsigneeDocumentNumber(object entity, List<ValidationResult> validationResultList, int index)
        {
            StringBuilder sb = new StringBuilder();
            ValidationResult validationResult = new ValidationResult();

            string errorMessage = string.Empty;
            List<string> memberNames = new List<string>();
            
            var props = entity.GetType().GetCustomAttributes(true);
            foreach (var item in props)
            {
                object value = entity;

                if (item.ToString().Equals("FSInterfaces.ValidaConsigneeDocumentNumber"))
                {
                    FSInterfaces.ConsigneeDocumentNumberAttribute validate = new ConsigneeDocumentNumberAttribute();
                    if (!validate.IsValid(value))
                    {
                        string entityName = value.GetType().Name;
                        memberNames.Add(entityName);
                        Consignee consignee = value as Consignee;
                        if ((consignee == null))
                            sb.Append("The entity " + entityName + " is not valid ") ;
                        else
                            sb.AppendLine("The Consignee DocumentNumber " + (consignee.ConsigneeDocumentNumber ?? string.Empty) + " not is valid for " + consignee.ConsigneeName + " with the documentType " + (consignee.ConsigneeDocumentType ?? string.Empty));
                    }
                }
            }

            if (memberNames.Count > 0)
            {
                validationResult.EntityName = entity.GetType().Name;
                validationResult.Index = index;
                validationResult.SetErrors(sb.ToString(), memberNames);
                validationResultList.Add(validationResult);
            }

            return validationResult.MemberNames.Count() == 0;
        }

        private static bool validateStringLength(object entity, List<ValidationResult> validationResultList,int index)
        {
            StringBuilder sb = new StringBuilder();
            ValidationResult validationResult = new ValidationResult();

            string errorMessage = string.Empty;
            List<string> memberNames = new List<string>();
            var props = entity.GetType().GetProperties().Where(p => p.GetCustomAttributes(typeof(System.ComponentModel.DataAnnotations.StringLengthAttribute), true).Count() > 0).ToList();
            foreach (var item in props)
            {
                object value = item.GetValue(entity, null);

                var x = item.GetCustomAttributes(true).ToList().Where(a => a.ToString().Equals("System.ComponentModel.DataAnnotations.StringLengthAttribute")).SingleOrDefault() as System.ComponentModel.DataAnnotations.StringLengthAttribute;
                if (x != null && value != null && !x.IsValid(value))
                {
                    memberNames.Add(item.Name);
                    if (!string.IsNullOrEmpty(x.ErrorMessage))
                        sb.Append(x.ErrorMessage);
                    else
                        sb.AppendLine("The MaximumLength for " + item.Name + " is " + x.MaximumLength.ToString() + " and the current Length is " + value.ToString().Length.ToString()); 
                }
            }

            if (memberNames.Count > 0)
            {
                validationResult.EntityName = entity.GetType().Name;
                validationResult.Index = index;
                validationResult.SetErrors(sb.ToString(), memberNames);
                validationResultList.Add(validationResult);
            }

            return validationResult.MemberNames.Count() == 0;
        }



        private static bool validateRequired(object entity, List<ValidationResult> validationResultList,int index)
        {
            StringBuilder sb = new StringBuilder();
            ValidationResult validationResult = new ValidationResult();
            string errorMessage = string.Empty;
            List<string> memberNames = new List<string>();
            var props = entity.GetType().GetProperties().Where(p => p.GetCustomAttributes(typeof(System.ComponentModel.DataAnnotations.RequiredAttribute), true).Count() > 0).ToList();
            foreach (var item in props)
            {
                object value = item.GetValue(entity, null);

                var x = item.GetCustomAttributes(true).ToList().Where(a => a.ToString().Equals("System.ComponentModel.DataAnnotations.RequiredAttribute")).SingleOrDefault() as System.ComponentModel.DataAnnotations.RequiredAttribute;
                if (x != null && (value == null || !x.IsValid(value)))
                {
                    memberNames.Add(item.Name);
                    if (!string.IsNullOrEmpty(x.ErrorMessage))
                        sb.Append(x.ErrorMessage);
                    else
                        sb.AppendLine(item.Name + " is Required");

                }
            }

            if (memberNames.Count > 0)
            {
                validationResult.EntityName = entity.GetType().Name;
                validationResult.Index = index;
                validationResult.SetErrors(sb.ToString(), memberNames);
                validationResultList.Add(validationResult);
            }

            return validationResult.MemberNames.Count() == 0;
        }

        private static bool validateRange(object entity, List<ValidationResult> validationResultList, int index)
        {
            StringBuilder sb = new StringBuilder();
            ValidationResult validationResult = new ValidationResult();
            string errorMessage = string.Empty;
            List<string> memberNames = new List<string>();
            var props = entity.GetType().GetProperties().Where(p => p.GetCustomAttributes(typeof(System.ComponentModel.DataAnnotations.RangeAttribute), true).Count() > 0).ToList();
            foreach (var item in props)
            {
                object value = item.GetValue(entity, null);

                var x = item.GetCustomAttributes(true).ToList().Where(a => a.ToString().Equals("System.ComponentModel.DataAnnotations.RangeAttribute")).SingleOrDefault() as System.ComponentModel.DataAnnotations.RangeAttribute;
                if (x != null && (value == null || !x.IsValid(value) ))
                {
                    memberNames.Add(item.Name);
                    if (!string.IsNullOrEmpty(x.ErrorMessage))
                        sb.Append(x.ErrorMessage);
                    else
                        sb.AppendLine("The valid range for " + item.Name + " must be " + x.Minimum.ToString() + " to " + x.Maximum.ToString()); 
                }
            }

            if (memberNames.Count > 0)
            {
                validationResult.EntityName = entity.GetType().Name;
                validationResult.Index = index;
                validationResult.SetErrors(sb.ToString(), memberNames);
                validationResultList.Add(validationResult);
            }

            return validationResult.MemberNames.Count() == 0;
        }


        private static bool compareRange(object minimum,object maximun, object value)
        {
            bool result = true;
           
            switch (value.GetType().ToString())
            {
                case "System.Int16":
                    result = Convert.ToInt16(minimum) >= Convert.ToInt16(value) && Convert.ToInt16(value) <= Convert.ToInt16(maximun);
                    break;

                case "System.Int32":
                    result = Convert.ToInt32(minimum) >= Convert.ToInt32(value) && Convert.ToInt32(value) <= Convert.ToInt32(maximun);
                    break;

                case "System.ToInt64":
                    result = Convert.ToInt64(minimum) >= Convert.ToInt64(value) && Convert.ToInt64(value) <= Convert.ToInt64(maximun);
                    break;

                case "System.Decimal":
                    result = Convert.ToDecimal(minimum) >= Convert.ToDecimal(value) && Convert.ToDecimal(value) <= Convert.ToDecimal(maximun);
                    break;

                case "System.Double":
                    result = Convert.ToDouble(minimum) >= Convert.ToDouble(value) && Convert.ToDouble(value) <= Convert.ToDouble(maximun);
                    break;

                case "System.DateTime":
                    result = Convert.ToDateTime(minimum) >= Convert.ToDateTime(value) && Convert.ToDateTime(value) <= Convert.ToDateTime(maximun);
                    break;

            }

            return result;
        }

    }
}