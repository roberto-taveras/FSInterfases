﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FSInterfaces
{
   
    public class DTOServiceImage
    {
        public int Id { get; set; }
        public int ServiceId { get; set; }
        public FSInterfaces.ServiceType ServiceType { get; set; }
        public string ImageName { get; set; }
        public string ImageSource { get; set; }
        public string CreatedUser { get; set; }
        public DateTime CreatedDate { get; set; }

    }
}
