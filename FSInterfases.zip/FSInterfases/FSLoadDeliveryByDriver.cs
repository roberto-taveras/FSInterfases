﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FSInterfaces
{
    public class ImagesFile
    {
        public string FileName { get; set; }
        public byte[] Content { get; set; }
    }

    public class FSLoadDeliveryByDriver
    {
      
        public int IdShipmentDetails { get; set; }
        public string NoBill { get; set; }
        public DateTime? Date { get; set; }
        public int? IdZone { get; set; }
        public string Zone { get; set; }
        public int? IdShipper { get; set; }
        public string Shipper { get; set; }
        public int? IdConsignee { get; set; }
        public string Consignee { get; set; }
        public int? QuantityPackage { get; set; }
        public int? IdClass { get; set; }
        public string Class { get; set; }
        public int? IdLocation { get; set; }
        public string Location { get; set; }
        public string GeneralNote { get; set; }
        public DateTime? CheckOutDate { get; set; }
        public int? IdShipping { get; set; }
        public int? QuantityDeliveredPackage { get; set; }
        public string received { get; set; }
        public DateTime? DeliveredDate { get; set; }
        public DateTime? DeliveredHour { get; set; }
        public int? IdPackageType { get; set; }
        public int? IdStatus { get; set; }
        public string DeliveryNote { get; set; }
        public DateTime? ModificationDate { get; set; }
        public int? IdDriver { get; set; }
        public string IMEI { get; set; }
        public string Pin { get; set; }
        public DateTime? CheckOutHour { get; set; }
        public DateTime? CheckOutD { get; set; }
        public string StatusName { get; set; }
        public string Address { get; set; }
        public string Latitude { get; set; }
        public string Longitud { get; set; }
        public string Telephone { get; set; }
        public ImagesFile DigitalSignature { get; set; }
        public List<ImagesFile> Images { get; set; }
        public int QuantityDamage { get; set; }

    }

}
