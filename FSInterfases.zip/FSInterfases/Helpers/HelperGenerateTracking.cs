﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FSInterfaces.Helpers
{
    public class HelperGenerateTracking
    {
        private HelperGenerateTracking()
        {

        }

        public static string Generate(string data)
        {

            if (string.IsNullOrEmpty(data))
                return string.Empty;
           

            int digVerificator = 0;
            for (int i = 0; i < data.Length; i++)
            {
                digVerificator += Convert.ToInt32(data[i]);
            }

            data += digVerificator.ToString().Last();

            return data;
        }

    }
}