﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;

namespace FSInterfaces
{
    public class ShippingResult : IShippingResult
    {
       
        [StringLength(50), Required]
        public string ConsigneeDocumentNumber { get; set; }

        
        [StringLength(50), Required]
        public string InvoiceNumber { get; set; }
        
     
        [StringLength(150)]
        public string InternalTrackingNumber { get; set; }

    }
}
