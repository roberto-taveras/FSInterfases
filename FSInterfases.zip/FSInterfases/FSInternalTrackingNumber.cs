﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;
using FSInterfaces.CustomValidations;
using FSInterfaces.CustomValidations;

namespace FSInterfaces
{
    public class FSInternalTrackingNumber
    {
        [StringLength(50), Required]
        [TrackingNumber]
        public string TrackingNumber { get; set; }
    }

    public class FSTrackingNumberList
    {
        public FSTrackingNumberList()
        {
            TrackingNumbers = new List<FSInternalTrackingNumber>();
        }
        public List<FSInternalTrackingNumber> TrackingNumbers { get; set; }
    }
}
